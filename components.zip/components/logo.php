    <!-- Fixed Logo Start -->
    <div class="logo loading__fade">
      <a href="#home" class="logo__link">
        <!-- logo icon -->
       <div class="logo-wrapper">
  <img src="img/logo.png" alt="Logo" class="logo-img">
</div>


        <!-- logo text -->
        <span class="logo-text">Portfolio</span>
      </a>
    </div>
    <!-- Fixed Logo End -->

    
