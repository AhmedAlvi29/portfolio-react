  <!-- Loader Start -->
  <div id="loader" class="loader">
      <div class="loader__wrapper">
        <div class="loader__content">
          <div class="loader__count">
            <span class="count__text">0</span>
            <span class="count__percent">%</span>
          </div>
        </div>
      </div>
    </div>
    <!-- Loader End -->
