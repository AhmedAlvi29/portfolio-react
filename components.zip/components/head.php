 <!-- Header Start -->
 <header id="header" class="header d-flex justify-content-center loading__fade">
      <!-- Navigation Menu Start -->
      <div class="header__navigation d-flex justify-content-start">
        <nav id="menu" class="menu">
          <ul class="menu__list d-flex justify-content-start">
            <li class="menu__item">
              <a class="menu__link btn" href="#home">
                <span class="menu__caption">Home</span>
                <i class="ph ph-house-simple"></i>
              </a>
            </li>
            <li class="menu__item">
              <a class="menu__link btn" href="#about">
                <span class="menu__caption">About Me</span>
                <i class="ph ph-user"></i>
              </a>
            </li>
            <li class="menu__item">
              <a class="menu__link btn" href="#services">
                <span class="menu__caption">Services</span>
                <i class="ph ph-sticker"></i>
              </a>
            </li>
            <li class="menu__item">
              <a class="menu__link btn" href="#resume">
                <span class="menu__caption">Resume</span>
                <i class="ph ph-article"></i>
              </a>
            </li>
            <li class="menu__item">
              <a class="menu__link btn" href="#contact">
                <span class="menu__caption">Contact</span>
                <i class="ph ph-envelope"></i>
              </a>
            </li>
          </ul>
        </nav>
      </div>
      <!-- Navigation Menu End -->
    </header>
    <!-- Header End -->
